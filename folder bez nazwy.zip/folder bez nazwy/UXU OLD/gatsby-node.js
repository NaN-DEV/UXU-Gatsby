exports.createPages = async ({ graphql, actions }) => {
  const { createPage } = actions

  const queryResults = await graphql(`
    query createPage {
      allDatoCmsTutorial {
        nodes {
          id
          slug
          title
          excerpt
          mainImage {
            alt
            url
          }
        }
      }
      allDatoCmsService {
        nodes {
          id
          slug
          title
          excerpt
          mainImage {
            alt
            url
          }
        }
      }
      allDatoCmsBlog {
        nodes {
          id
          slug
          title
          excerpt
          mainImage {
            url
            alt
          }
        }
      }
    }
  `)
  queryResults.data.allDatoCmsTutorial.nodes.forEach((content, index) => {
    createPage({
      path: `/poradniki/${content.slug}`,
      component: require.resolve(`./src/templates/tutorial.js`),
      context: { content, index },
    })
  })
  queryResults.data.allDatoCmsService.nodes.forEach((content, index) => {
    createPage({
      path: `/serwis/${content.slug}`,
      component: require.resolve(`./src/templates/service.js`),
      context: { content, index },
    })
  })
  queryResults.data.allDatoCmsBlog.nodes.forEach((content, index) => {
    createPage({
      path: `/blog/${content.slug}`,
      component: require.resolve(`./src/templates/blog.js`),
      context: { content, index },
    })
  })
}
